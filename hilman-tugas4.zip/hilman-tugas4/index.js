// mengubah teks menjasi UpperCase
let teks1 = "merah putih"
let teks2 = "MERAH PUTIH"
let uppercase = teks1.toUpperCase()

// mengubah teks menjadi LowerCase
let lowercase = teks2.toLowerCase()

// variabel mengukur panjang(length)
let teks12 = "merah putih"
let ubahTeks = teks12.replace ("putih", "muda")

// variabel mengukur panjang (length)
let teks11 = "merah putih"
let panjangteks = teks11.length

// mengambil output
alert(uppercase)
alert(lowercase)
alert(ubahTeks)
alert(panjangteks)
